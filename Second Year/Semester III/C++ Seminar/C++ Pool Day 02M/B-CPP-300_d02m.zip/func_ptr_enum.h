/*
** EPITECH PROJECT, 2018
** cpp_d02m
** File description:
** ex03
*/

#ifndef FUNC_PTR_ENUM_H_
# define FUNC_PTR_ENUM_H_

typedef enum action_e
{
    PRINT_NORMAL,
    PRINT_REVERSE,
    PRINT_UPPER,
    PRINT_42
}   action_t;

#endif /* FUNC_PTR_ENUM_H_ */
