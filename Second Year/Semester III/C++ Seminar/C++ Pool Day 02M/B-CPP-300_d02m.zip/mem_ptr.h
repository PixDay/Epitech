/*
** EPITECH PROJECT, 2018
** cpp_d02m
** File description:
** ex01
*/

#ifndef MEM_PTR_H
# define MEM_PTR_H

typedef struct str_op_s
{
    const char  *str1;
    const char  *str2;
    char        *res;
}   str_op_t;

#endif /* MEM_PTR_H */
