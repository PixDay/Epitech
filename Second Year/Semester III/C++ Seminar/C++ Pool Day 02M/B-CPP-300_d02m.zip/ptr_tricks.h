/*
** EPITECH PROJECT, 2018
** cpp_d02m
** File description:
** ex05
*/

#ifndef PTR_TRICKS_H_
# define PTR_TRICKS_H_

typedef struct whatever_s
{
    float   f;
    int     member;
    char    c;
}   whatever_t;

#endif /* !PTR_TRICKS_H_ */

